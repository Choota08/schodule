<?php

namespace App\Imports;

use App\Models\User;
use App\Models\Subject;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\SkipsFailures;

class UsersImport implements
    ToModel,
    WithHeadingRow,
    WithValidation,
    SkipsOnFailure
{
    use SkipsFailures;

    protected string $role;

    public function __construct(string $role)
    {
        $this->role = $role;
    }

    public function model(array $row)
    {
        return DB::transaction(function () use ($row) {

            // Mapping

            if ($this->role === 'teacher') {

                $kodeUser = $row['id_pengajar'];
                $name = $row['nama_pengajar'];
                $password = $row['password_default'];
                $subjectInput = $row['mapel'] ?? null;

            } else {

                $kodeUser = $row['id_siswa'];
                $name = $row['nama_siswa'];
                $password = $row['password_default'];
                $subjectInput = null;
            }

            // USER

            $user = User::create([
                'kode_user' => trim($kodeUser),
                'name'      => trim($name),
                'role'      => $this->role,
                'password'  => Hash::make($password),
            ]);

            // STUDENT

            if ($this->role === 'student') {

                $user->student()->create([]);

            }

            // TEACHER

            if ($this->role === 'teacher') {

                $subjectName = strtolower(trim($subjectInput));

                $subject = Subject::where(DB::raw('LOWER(name)'), $subjectName)->first();

                $user->teacher()->create([
                    'subject_id' => $subject?->id,
                    'subject_name_pending' => $subject ? null : $subjectInput
                ]);
            }

            return $user;
        });
    }

    // validation rules

    public function rules(): array
    {
        if ($this->role === 'teacher') {

            return [
                '*.id_pengajar' => 'required|distinct|unique:users,kode_user',
                '*.nama_pengajar' => 'required|string|max:255',
                '*.password_default' => 'required|min:3',
                '*.mapel' => 'required|string'
            ];
        }

        return [
            '*.id_siswa' => 'required|distinct|unique:users,kode_user',
            '*.nama_siswa' => 'required|string|max:255',
            '*.password_default' => 'required|min:3'
        ];
    }
}
